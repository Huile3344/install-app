#!/bin/bash

echo "# systemctl stop yum-cron && systemctl disable yum-cron"
systemctl stop yum-cron && systemctl disable yum-cron
