#!/bin/bash
echo "vim  -e  -s  -c  \"%s/\\r//g\"  -c \"wq\"  $1"
vi  -e  -s  -c  "%s/\r//g"  -c "wq"  $1
echo "chmod +x $1"
chmod +x $1
