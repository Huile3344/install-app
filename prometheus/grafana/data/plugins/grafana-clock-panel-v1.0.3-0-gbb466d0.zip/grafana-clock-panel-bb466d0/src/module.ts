import {ClockCtrl} from './clock_ctrl';

export {
  ClockCtrl as PanelCtrl
};
